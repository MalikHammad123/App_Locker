package com.example.app_locker.activities.intruder

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.CompoundButton
import android.widget.ImageView
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil.setContentView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.app_locker.R
import com.example.app_locker.adapters.adapter.CapturedImagesAdapter
import com.example.app_locker.bottomsheets.WrongAttemptBottomSheet
import com.google.android.material.appbar.MaterialToolbar
import java.io.File


class IntruderActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: CapturedImagesAdapter
    lateinit var nophoto: ImageView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var switchView: Switch
    companion object {
        private const val PREFS_NAME = "IntruderPrefs"
        private const val SWITCH_STATE_KEY = "switchState"
    }

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intruder)




            sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            switchView = findViewById(R.id.intruder_sv)

            // Retrieve the switch state from SharedPreferences
            val switchState = sharedPreferences.getBoolean(SWITCH_STATE_KEY, false)

            // Set the initial state of the switch
            switchView.isChecked = switchState

            // Listen for switch state changes and save it in SharedPreferences
            switchView.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
                sharedPreferences.edit().putBoolean(SWITCH_STATE_KEY, isChecked).apply()
            }



        nophoto = findViewById(R.id.nophoto_iv)
        recyclerView = findViewById(R.id.intruder_recycler_view)
        recyclerView.layoutManager = GridLayoutManager(this, 3)
        adapter = CapturedImagesAdapter()
        recyclerView.adapter = adapter

        // Load and display the pictures in the adapter
        val picturesList = loadPicturesFromCache()
        if (picturesList.size > 0) {
            nophoto.visibility = View.GONE
        }
        adapter.setPictures(picturesList)

        val materialToolbar: MaterialToolbar = findViewById(R.id.material_tb)
        materialToolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.delete -> {
                    deletepictures()
                    true
                }
                R.id.setting -> {
                    openBottomSheet()
                    true
                }
                else -> false
            }
        }
    }

    private fun openBottomSheet(){

        val bottomSheetFragment = WrongAttemptBottomSheet()
        bottomSheetFragment.show(supportFragmentManager, "bottomSheetFragment")
    }
    private fun deletepictures() {
        val selectedPositions = adapter.getSelectedPositions()
        val selectedPictures = selectedPositions.mapNotNull { position -> adapter.getPictureFile(position) }

        // Delete selected pictures from cache and data list
        for (pictureFile in selectedPictures) {
            if (pictureFile.delete()) {
                adapter.removePicture(pictureFile)
            }
        }

        adapter.clearSelections()
        adapter.notifyDataSetChanged()
    }

    private fun loadPicturesFromCache(): List<File> {
        val cacheDir = cacheDir
        val picturesList: MutableList<File> = mutableListOf()

        val files = cacheDir.listFiles()
        files?.let {
            for (file in it) {
                if (file.isFile) {
                    picturesList.add(file)
                }
            }
        }
        return picturesList
    }
}

