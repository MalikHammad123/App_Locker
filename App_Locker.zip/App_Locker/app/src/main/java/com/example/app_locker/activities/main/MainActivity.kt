package com.example.app_locker.activities.main

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.viewpager.widget.ViewPager
import com.example.app_locker.R
import com.example.app_locker.activities.setting.Setting
import com.example.app_locker.activities.theme.Theme
import com.example.app_locker.adapters.viewpager.MainViewPagerAdapter
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        //val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        val viewPager = findViewById<ViewPager>(R.id.viewPager)
/////////////////////////////////////////////

        ////////////////////////////////////

        viewPager.adapter = MainViewPagerAdapter(supportFragmentManager)
        tabLayout.setupWithViewPager(viewPager)
        val materialToolbar: MaterialToolbar = findViewById(R.id.material_tb)
        materialToolbar.setOnClickListener {
            val intent = Intent(this, Setting::class.java)
            startActivity(intent)
        }

        materialToolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.premium -> {
                    showdialogue()

                    true
                }
                R.id.theme -> {
                    startActivity(Intent(this, Theme::class.java))
                    true
                }
                else -> false
            }

        }
    }


    fun showdialogue() {

        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialogue_box)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val unlocktv = dialog.findViewById<TextView>(R.id.unlock_tv)
        unlocktv.setOnClickListener {
            // Add code to handle click events for the "Cross" button here
            dialog.dismiss() // close the dialog
        }

        val locktv = dialog.findViewById<TextView>(R.id.lock_tv)
        locktv.setOnClickListener {
            // Add code to handle click events for the "Continue" button here
            val intent = Intent(this, Theme::class.java)
            startActivity(intent)
        }

        dialog.show()

    }

}
