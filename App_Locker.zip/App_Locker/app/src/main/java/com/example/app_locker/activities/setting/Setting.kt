package com.example.app_locker.activities.setting

import com.example.app_locker.bottomsheets.SecurityQuestionsBottomSheet
import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.app_locker.R
import com.example.app_locker.activities.login.LoginActivity
import com.example.app_locker.directory.utils.SwitchHandler
import com.example.app_locker.fragments.vip.VipFragment


class Setting : AppCompatActivity(), SecurityQuestionsBottomSheet.SecurityQuestionsListener {

    private lateinit var securityQuestionsBottomSheet: SecurityQuestionsBottomSheet
    private var question: String = ""
    private var answer: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        securityQuestionsBottomSheet = SecurityQuestionsBottomSheet.newInstance()
        securityQuestionsBottomSheet.setListener(this)

        val frameLayout1: FrameLayout = findViewById(R.id.framef1)
        val setQuestionsButton: FrameLayout = findViewById(R.id.framef5)
        val share: FrameLayout = findViewById(R.id.framef6)
        val VIP: FrameLayout = findViewById(R.id.framef0)
        val fingerprint: Switch = findViewById(R.id.fingerprint_sv)
        val privacypolicy: FrameLayout = findViewById(R.id.framef8)
        val passwordreset: FrameLayout = findViewById(R.id.framef4)


// Listen to switch state changes

        passwordreset.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("reset_password_from_setting", true)
            startActivity(intent)
        }

        val switchState = SwitchHandler.getSwitchState(fingerprint.context)
        fingerprint.isChecked = switchState

        fingerprint.setOnCheckedChangeListener { _, isChecked ->
            SwitchHandler.saveSwitchState(this, isChecked)
        }

        VIP.setOnClickListener {
            val fragment = VipFragment()
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, fragment)
                .commit()
        }
        frameLayout1.setOnClickListener {
            showSmallBox()
        }
        setQuestionsButton.setOnClickListener {

            securityQuestionsBottomSheet.show(supportFragmentManager, "securityQuestions")
        }
        share.setOnClickListener {
            shareApplication()
        }


    }
    private fun shareApplication() {
        val appPackageName = packageName
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Check out this awesome app: https://example.com/your-app-download-link")
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, "Share via"))
    }
    private fun showSmallBox() {
        // Perform action for Option 1
    }
    override fun onSetQuestions(question: String, answer: String) {
        this.question = question
        this.answer = answer
        Toast.makeText(this,"Answers set",Toast.LENGTH_SHORT).show()
        // Implement the logic to save the security question and answer
        // based on the received values
    }
    override fun onVerifyQuestions(answer: String): Boolean {
        // Verify the security question answer
        return this.answer == answer
    }
}
