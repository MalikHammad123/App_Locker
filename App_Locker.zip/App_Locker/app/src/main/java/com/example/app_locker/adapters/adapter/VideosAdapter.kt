package com.example.app_locker.adapters.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.VideoView
import androidx.recyclerview.widget.RecyclerView
import com.example.app_locker.R
import com.example.app_locker.directory.utils.MediaStoreVideo

class VideosAdapter(private val videoList: List<MediaStoreVideo>) :
    RecyclerView.Adapter<VideosAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val videoView: VideoView = itemView.findViewById(R.id.video_vv)

        fun bind(video: MediaStoreVideo) {
            try {
                videoView.setVideoURI(video.contentUri)
                videoView.setOnPreparedListener { mediaPlayer ->
                    // Adjust the video view size to match the video's aspect ratio
                    val videoWidth = mediaPlayer.videoWidth
                    val videoHeight = mediaPlayer.videoHeight
                    val videoProportion = videoWidth.toFloat() / videoHeight.toFloat()

                    val layoutParams = videoView.layoutParams
                    layoutParams.width = videoView.width
                    layoutParams.height = (videoView.width / videoProportion).toInt()
                    videoView.layoutParams = layoutParams

                    // Start playing the video
                    mediaPlayer.start()
                }
            } catch (e: Exception) {
                // Debugging: log exceptions
                Log.e("DownloadedVideoAdapter", "Failed to load video from path: ${video.path}", e)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.videos_recycler_view, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(videoList[position])
    }

    override fun getItemCount() = videoList.size
}
