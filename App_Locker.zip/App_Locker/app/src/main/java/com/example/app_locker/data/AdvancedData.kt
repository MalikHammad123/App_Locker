package com.example.app_locker.data

data class AdvancedData (val text: String, val imageResId: Int,val switch:Boolean)