package com.example.app_locker.directory.utils
import android.content.*
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

import android.graphics.Bitmap
import android.os.Build

import android.preference.PreferenceManager
import android.provider.MediaStore
import android.util.Log
import com.example.app_locker.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.security.SecureRandom
import java.util.*
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.spec.SecretKeySpec


object ImageStorageHelper {
    private const val IMAGE_PREF_KEY = "stored_images"
///////////////////////working saving and retriving properly///////////////////////

    fun saveImageToStorage(context: Context, bitmap: Bitmap, folderName: String): String? {
        val filename = "${System.currentTimeMillis()}.jpg"
        var imageUri: Uri?
        var imagePath: String? = null

        try {
            var fos: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folderPath =
                    Environment.DIRECTORY_PICTURES + File.separator + context.resources.getString(R.string.app_name) + File.separator + folderName

                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, folderPath)
                    put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                }

                val resolver = context.contentResolver
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                imageUri?.let { uri ->
                    fos = resolver.openOutputStream(uri)
                    val file = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), folderName)
                    imagePath = file.absolutePath
                    imageUri = Uri.fromFile(file)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val folderDir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), folderName)
                if (!folderDir.exists()) {
                    folderDir.mkdirs()
                }


                val image = File(folderDir, filename)
                fos = FileOutputStream(image)
                imageUri = Uri.fromFile(image)
                imagePath = image.absolutePath
                Log.d("ABC", "URI: $imagePath")
            }

            fos?.use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.d("ABC", "URI: $imagePath")
        return imagePath
    }
    suspend fun getGalleryImages(context: Context, folderName: String): List<MediaStoreImage> {
        val images = mutableListOf<MediaStoreImage>()
        withContext(Dispatchers.IO) {
            try {
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.DATA
                )
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

                val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    MediaStore.MediaColumns.RELATIVE_PATH + " like ? "
                else MediaStore.Images.Media.DATA + " like ? "

                val selectionArgs = arrayOf("%$folderName%")
                val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

                context.contentResolver.query(
                    collection,
                    projection,
                    selection,
                    selectionArgs,
                    sortOrder
                )?.use { cursor ->
                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val dateModifiedColumn =
                        cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    val displayNameColumn =
                        cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val idx = cursor.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idColumn)
                        val dateModified =
                            Date(TimeUnit.SECONDS.toMillis(cursor.getLong(dateModifiedColumn)))
                        val displayName = cursor.getString(displayNameColumn)
                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            id
                        )
                        val path = cursor.getString(idx)
                        val image = MediaStoreImage(id, displayName, dateModified, contentUri, path)
                        images += image
                    }
                }
            } catch (e: Exception) {

            }
        }
        return images
    }
    fun saveVideoToStorage(context: Context, videoUri: Uri, folderName: String): String? {
        val filename = "${System.currentTimeMillis()}.mp4"
        var videoPath: String? = null

        try {
            val resolver = context.contentResolver

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folderPath =
                    Environment.DIRECTORY_MOVIES + File.separator + context.resources.getString(R.string.app_name) + File.separator + folderName

                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, folderPath)
                    put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                }

                val videoCollectionUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val videoUri = resolver.insert(videoCollectionUri, contentValues)

                videoUri?.let { uri ->
                    val inputStream = context.contentResolver.openInputStream(videoUri)
                    val outputStream = resolver.openOutputStream(uri)

                    if (inputStream != null && outputStream != null) {
                        inputStream.copyTo(outputStream)
                        videoPath = uri.toString()
                    }

                    inputStream?.close()
                    outputStream?.close()
                }
            } else {
                val folderDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), folderName)
                if (!folderDir.exists()) {
                    folderDir.mkdirs()
                }

                val videoFile = File(folderDir, filename)
                val inputStream = context.contentResolver.openInputStream(videoUri)
                val outputStream = FileOutputStream(videoFile)

                if (inputStream != null && outputStream != null) {
                    inputStream.copyTo(outputStream)
                    videoPath = videoFile.absolutePath
                }

                inputStream?.close()
                outputStream?.close()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        return videoPath
    }
    suspend fun getGalleryVideos(context: Context, folderName: String): List<MediaStoreVideo> {
        val videos = mutableListOf<MediaStoreVideo>()
        withContext(Dispatchers.IO) {
            try {
                val projection = arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.DATE_ADDED,
                    MediaStore.Video.Media.DATA,
                    MediaStore.Video.Media.DURATION
                )
                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

                val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    MediaStore.MediaColumns.RELATIVE_PATH + " like ? "
                else MediaStore.Video.Media.DATA + " like ? "

                val selectionArgs = arrayOf("%$folderName%")
                val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

                context.contentResolver.query(
                    collection,
                    projection,
                    selection,
                    selectionArgs,
                    sortOrder
                )?.use { cursor ->
                    val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                    val displayNameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val idx = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATA)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idColumn)
                        val dateAdded = Date(TimeUnit.SECONDS.toMillis(cursor.getLong(dateAddedColumn)))
                        val displayName = cursor.getString(displayNameColumn)
                        val duration = cursor.getLong(durationColumn)
                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            id
                        )
                        val path = cursor.getString(idx)
                        val video = MediaStoreVideo(id, displayName, dateAdded, contentUri, path, duration)
                        videos += video
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return videos
    }


////////////////////////////////////////////////////////////////////////

  /*  fun saveImageToStorage(context: Context, bitmap: Bitmap, folderName: String): String? {
        val filename = "${System.currentTimeMillis()}.jpg"
        var imageUri: Uri?
        var imagePath: String? = null

        try {
            var fos: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folderPath =
                    Environment.DIRECTORY_PICTURES + File.separator + context.resources.getString(R.string.app_name) + File.separator + folderName

                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, folderPath)
                    put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                }

                val resolver = context.contentResolver
                imageUri =
                    resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                imageUri?.let { uri ->
                    fos = resolver.openOutputStream(uri)
                    val file = File(
                        context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                        folderName
                    )
                    imagePath = file.absolutePath
                    imageUri = Uri.fromFile(file)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val folderDir =
                    File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), folderName)
                if (!folderDir.exists()) {
                    folderDir.mkdirs()
                }

                val image = File(folderDir, filename)
                fos = FileOutputStream(image)
                imageUri = Uri.fromFile(image)
                imagePath = image.absolutePath
                Log.d("ABC", "URI: $imagePath")
            }

            fos?.use { outputStream ->
                // Encrypt the bitmap data before writing it to the output stream
                encryptBitmap(bitmap, outputStream)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.d("ABC", "URI: $imagePath")
        return imagePath
    }
    private fun encryptBitmap(bitmap: Bitmap, outputStream: OutputStream) {
        val key = generateKey()
        val cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val cipherOutputStream = CipherOutputStream(outputStream, cipher)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, cipherOutputStream)
        cipherOutputStream.close()
    }
    private fun generateKey(): SecretKeySpec {
        val keyGenerator = KeyGenerator.getInstance("AES")
        keyGenerator.init(256, SecureRandom())
        val secretKey = keyGenerator.generateKey()
        return SecretKeySpec(secretKey.encoded, "AES")
    }
    fun getGalleryImages(context: Context, folderName: String): List<MediaStoreImage> {
        val images = mutableListOf<MediaStoreImage>()
        try {
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DATA
            )
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                MediaStore.MediaColumns.RELATIVE_PATH + " like ? "
            else MediaStore.Images.Media.DATA + " like ? "

            val selectionArgs = arrayOf("%$folderName%")
            val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

            context.contentResolver.query(
                collection,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateModifiedColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val displayNameColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val idx = cursor.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val dateModified =
                        Date(TimeUnit.SECONDS.toMillis(cursor.getLong(dateModifiedColumn)))
                    val displayName = cursor.getString(displayNameColumn)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val path = cursor.getString(idx)

                    // Decrypt the image file before creating the MediaStoreImage object
                    val decryptedPath = decryptImageFile(path)

                    val image =
                        MediaStoreImage(id, displayName, dateModified, contentUri, decryptedPath)
                    images += image
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return images
    }
    private fun decryptImageFile(path: String): String {
        val encryptedFile = File(path)
        val decryptedFile = File(path.replace(".jpg", "_decrypted.jpg"))

        val key = generateKey()
        val cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.DECRYPT_MODE, key)

        encryptedFile.inputStream().use { inputStream ->
            decryptedFile.outputStream().use { outputStream ->
                val cipherInputStream = CipherInputStream(inputStream, cipher)
                cipherInputStream.copyTo(outputStream)
                cipherInputStream.close()
            }
        }

        return decryptedFile.absolutePath
    }
*/

/*
    fun saveImageToStorage(context: Context, bitmap: Bitmap, folderName: String): String? {
        val filename = "${System.currentTimeMillis()}.jpg"
        var imageUri: Uri?
        var imagePath: String? = null

        try {
            var fos: OutputStream? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folderPath = "${Environment.DIRECTORY_PICTURES}/${context.resources.getString(R.string.app_name)}/$folderName"

                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, folderPath)
                    put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                }

                val resolver = context.contentResolver
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                imageUri?.let { uri ->
                    fos = resolver.openOutputStream(uri)
                    val file = File(context.getExternalFilesDir(null), "$folderName/$filename")
                    imagePath = file.absolutePath
                    imageUri = Uri.fromFile(file)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val folderDir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), folderName)
                if (!folderDir.exists()) {
                    folderDir.mkdirs()
                }

                val image = File(folderDir, filename)
                fos = FileOutputStream(image)
                imageUri = Uri.fromFile(image)
                imagePath = image.absolutePath
                Log.d("ABC", "URI: $imagePath")
            }

            fos?.use { outputStream ->
                // Encrypt the bitmap data before writing it to the output stream
                encryptBitmap(bitmap, outputStream)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.d("ABC", "URI: $imagePath")
        return imagePath
    }
    private fun encryptBitmap(bitmap: Bitmap, outputStream: OutputStream) {
        val key = generateKey()
        val cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val cipherOutputStream = CipherOutputStream(outputStream, cipher)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, cipherOutputStream)
        cipherOutputStream.close()
    }
    private fun generateKey(): SecretKeySpec {
        val keyGenerator = KeyGenerator.getInstance("AES")
        keyGenerator.init(256, SecureRandom())
        val secretKey = keyGenerator.generateKey()
        return SecretKeySpec(secretKey.encoded, "AES")
    }
    fun getGalleryImages(context: Context, folderName: String): List<MediaStoreImage> {
        val images = mutableListOf<MediaStoreImage>()
        try {
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.DATA
            )
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

            val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                MediaStore.MediaColumns.RELATIVE_PATH + " like ? "
            else MediaStore.Images.Media.DATA + " like ? "

            val selectionArgs = arrayOf("%$folderName%")
            val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

            context.contentResolver.query(
                collection,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val dateModifiedColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val displayNameColumn =
                    cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val idx = cursor.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val dateModified =
                        Date(TimeUnit.SECONDS.toMillis(cursor.getLong(dateModifiedColumn)))
                    val displayName = cursor.getString(displayNameColumn)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val path = cursor.getString(idx)

                    // Decrypt the image file before creating the MediaStoreImage object
                    val decryptedPath = decryptImageFile(path)

                    if (decryptedPath != null) {
                        val image =
                            MediaStoreImage(id, displayName, dateModified, contentUri, decryptedPath)
                        images += image
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return images
    }
    private fun decryptImageFile(path: String): String? {
        val encryptedFile = File(path)
        val decryptedFile = File(path.replace(".jpg", "_decrypted.jpg"))

        val key = generateKey()
        val cipher = Cipher.getInstance("AES")
        cipher.init(Cipher.DECRYPT_MODE, key)

        try {
            encryptedFile.inputStream().use { inputStream ->
                decryptedFile.outputStream().use { outputStream ->
                    val cipherInputStream = CipherInputStream(inputStream, cipher)
                    cipherInputStream.copyTo(outputStream)
                    cipherInputStream.close()
                }
            }

            return decryptedFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return null
    }
*/


}
/*
    private fun createImageFile(folderName: String, context: Context): File {
        val dir = File(
            Environment.getExternalStorageDirectory()
                .toString() + File.separator + context.resources.getString(
                R.string.app_name
            ) + File.separator + folderName
        )
        // Make sure the path directory exists.
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }
    fun getStoredImages(context: Context): List<Uri> {
        val storedImageUris = getStoredImageUris(context)
        return storedImageUris.map { Uri.parse(it) }
    }
    private fun getStoredImageUris(context: Context): MutableList<String> {
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        return sharedPreferences.getStringSet(IMAGE_PREF_KEY, mutableSetOf())?.toMutableList() ?: mutableListOf()
    }
    private fun createImageFile(context: Context, folderName: String): String? {
        var folderPath: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            folderPath =
                Environment.DIRECTORY_PICTURES + File.separator + context.resources.getString(
                    R.string.app_name
                ) + File.separator + folderName
        } else {
            folderPath = Environment.getExternalStorageDirectory()
                .toString() + File.separator + context.resources.getString(
                R.string.app_name
            ) + File.separator + folderName
        }
        return folderPath
    }


    suspend fun deleteFolder(path: String) {
        withContext(Dispatchers.IO) {
            val dir = File(path)
            if (dir.exists()) {
                val files = dir.listFiles()
                files?.forEach { file ->
                    if (file.isDirectory) {
                        launch {
                            deleteFolder(file.path)
                        }
                    } else {
                        file.delete()
                    }
                }
            }
            dir.delete()
        }
    }*/

