package com.example.app_locker.directory.utils


import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast

object PasswordUtils {
    var isResetting: Boolean = false

    fun resetPassword(context: Context, sharedPreferences: SharedPreferences, newPassword: String) {
        // Save the new password in SharedPreferences
        sharedPreferences.edit().putString("passcode", newPassword).apply()

        // Set the isResetting flag to true
        isResetting = true

        // Add any additional logic you need for resetting the password

        Toast.makeText(context, "Password reset successful", Toast.LENGTH_SHORT).show()
    }
}