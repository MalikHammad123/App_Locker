import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.app_locker.R
import com.example.app_locker.adapters.adapter.ImagesAdapter
import com.example.app_locker.adapters.adapter.VideosAdapter
import com.example.app_locker.directory.utils.ImageStorageHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch
class VideoFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: VideosAdapter

    companion object {
        private const val GALLERY_REQUEST_CODE = 1
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_video, container, false)
        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.video_recycler_view)
        getAllVideos()

        // Set OnClickListener for FAB
        val fab: FloatingActionButton = view.findViewById(R.id.video_floating_ab)
        fab.setOnClickListener {
            openGallery()
        }

        return view
    }

    private fun loadAndProcessVideo(uri: Uri, context: Context) {
        lifecycleScope.launch {
            ImageStorageHelper.saveVideoToStorage(context, uri, "Hammad_videos")
            getAllVideos()
        }
    }



    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_GET_CONTENT)
        galleryIntent.type = "video/*"
        galleryIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                val clipData = data.clipData

                if (clipData != null) {
                    for (i in 0 until clipData.itemCount) {
                        val videoUri: Uri? = clipData.getItemAt(i).uri
                        videoUri?.let {
                            loadAndProcessVideo(it, requireContext())
                        }
                    }
                } else {
                    val videoUri: Uri? = data?.data
                    videoUri?.let {
                        loadAndProcessVideo(it, requireContext())
                    }
                }
            }
        }
    }

    fun getAllVideos() {
        lifecycleScope.launch {
            val videoList = ImageStorageHelper.getGalleryVideos(requireContext(), "Hammad_videos")
            adapter = VideosAdapter(videoList)
            recyclerView.adapter = adapter
            recyclerView.layoutManager = GridLayoutManager(activity, 3)
        }
    }
}
