package com.example.app_locker.fragments.themes

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.app_locker.R
import com.example.app_locker.adapters.adapter.DownloadedImageAdapter
import com.example.app_locker.directory.utils.ImageStorageHelper
import kotlinx.coroutines.launch

class DownloadedThemeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DownloadedImageAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_downloaded_theme, container, false)
        recyclerView = view.findViewById(R.id.downloaded_recycler_view)
        recyclerView.layoutManager = GridLayoutManager(context,2)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        lifecycleScope.launch {
            val imagePaths = ImageStorageHelper.getGalleryImages(requireContext(), "hammad_themes")
            adapter = DownloadedImageAdapter(imagePaths)
            recyclerView.adapter = adapter
        }
    }
}

